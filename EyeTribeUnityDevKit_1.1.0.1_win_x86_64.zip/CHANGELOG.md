# Change Log #
---

Version 1.1.0.1 (2016-11-25)
---

- Improved Calibration UI flow
- Updated EyeTribe C# SDK dependency to v.0.9.77.6

Version 1.1.0.0 (2016-09-26)
---

- Scene flow and interaction improvements
- Project Restructuring for easier export/import
- New key input mapping
- Updated EyeTribe C# SDK dependency to v.0.9.77.5

Version 1.0.0.1 (2016-06-07)
---

- Bug fixes


Version 1.0.0.0 (2016-06-03)
---

- Initial release